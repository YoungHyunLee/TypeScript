# TypeScript Sample: Windows 8.1 Windows store app 

## Overview 

The encyclopedia includes a complete sample app for a Windows 8.1 app
built using TypeScript.  The following features of TypeScript are highlighted:
- VS project integration:  TypeScript compilation integrated into VS build
- Typing WinJS and WinRT:  Early work on typing these libraries
- Mostly JS in TypeScript:  Code is mostly the original JS, with a little 
  TypeScript

## Running 
```
Open encyclopedia\Encyclopedia.sln in Visual Studio 2013
F5
```
