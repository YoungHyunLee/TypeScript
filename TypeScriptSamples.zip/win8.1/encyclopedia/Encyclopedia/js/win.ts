///<reference path='typings\winrt.d.ts'/>
///<reference path='typings\winjs.d.ts'/>

declare var msSetImmediate: (expression: any) => void;