declare module "os" {
    export var EOL: string;
}