import { Dispatcher } from 'flux';

const dispatcherInstance = new Dispatcher();

export default dispatcherInstance;
