const GreetingActionTypes = {
  ADD_GREETING: 'GreetingActionTypes.ADD_GREETING',
  REMOVE_GREETING: 'GreetingActionTypes.REMOVE_GREETING',
  NEW_GREETING_CHANGED: 'GreetingActionTypes.NEW_GREETING_CHANGED'
};

export default GreetingActionTypes;
