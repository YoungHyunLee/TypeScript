**Fetch dependencies:**
```
npm install
```

**Run (using port 8080)**
```
npm start
```

**Run server on custom port**
```
node node_modules/http-server/bin/http-server -p 8080
```

'-p' sets the port to use, default port is 8080. If it is taken pick any port that is free. 
After server is started open 'localhost:8080' in a browser.