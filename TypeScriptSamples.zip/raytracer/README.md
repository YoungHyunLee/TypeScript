# TypeScript Sample: Raytracer 

## Overview 

This sample shows a raytracer implementation in TypeScript.

## Running
```
tsc --sourcemap raytracer.ts
start raytracer.html
```
